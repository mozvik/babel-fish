export const environment = {
  production: true,
  baseUrl: 'https://libretranslate.de'
};
